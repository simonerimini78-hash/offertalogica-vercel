import fs from "node:fs";
import path from "node:path";

const targetPath = path.resolve(process.cwd(), "public/index.html");
const PREFIX = "[fix-offerte-consulente]";

function countOccurrences(text, needle) {
  if (!needle) return 0;
  return text.split(needle).length - 1;
}

if (!fs.existsSync(targetPath)) {
  throw new Error(`${PREFIX} File non trovato: ${targetPath}`);
}

const original = fs.readFileSync(targetPath, "utf8");
const originalEol = original.includes("\r\n") ? "\r\n" : "\n";
let content = original.replace(/\r\n/g, "\n");

const oldRankingSort = `.sort((a, b) => (b.differenza - a.differenza) || (a.costo - b.costo))`;
const newRankingSort = `.sort((a, b) => (a.costo - b.costo) || (b.differenza - a.differenza))`;

const oldConsultantBlock = `  const chiaviPartnerAttivabili = new Set(attivabiliPrioritarie.map((item) => chiaveGruppoPartner(item)));
  const miglioriConConsulente = ordinateRanking
    .filter((item) => !item.attivabileOnline)
    .filter((item) => !chiaviPartnerAttivabili.has(chiaveGruppoPartner(item)))
    .slice(0, 3)`;

const newConsultantBlock = `  const miglioriConConsulente = ordinateRanking
    .filter((item) => !item.attivabileOnline)
    .slice(0, 3)`;

const alreadyFixed =
  countOccurrences(content, newRankingSort) >= 2 &&
  content.includes(newConsultantBlock) &&
  !content.includes(oldConsultantBlock);

if (alreadyFixed) {
  console.log(`${PREFIX} Correzione già presente. Nessuna modifica necessaria.`);
  process.exit(0);
}

const rankingSortCount = countOccurrences(content, oldRankingSort);
if (rankingSortCount !== 2) {
  throw new Error(
    `${PREFIX} Controllo di sicurezza non superato: attese 2 graduatorie precedenti, trovate ${rankingSortCount}. ` +
    "Il file public/index.html potrebbe essere cambiato: non applico sostituzioni automatiche."
  );
}

const consultantBlockCount = countOccurrences(content, oldConsultantBlock);
if (consultantBlockCount !== 1) {
  throw new Error(
    `${PREFIX} Controllo di sicurezza non superato: atteso 1 blocco consulente precedente, trovato ${consultantBlockCount}. ` +
    "Il file public/index.html potrebbe essere cambiato: non applico sostituzioni automatiche."
  );
}

content = content.split(oldRankingSort).join(newRankingSort);
content = content.replace(oldConsultantBlock, newConsultantBlock);

if (countOccurrences(content, newRankingSort) < 2 || content.includes(oldConsultantBlock)) {
  throw new Error(`${PREFIX} Verifica finale non superata. Il file non è stato scritto.`);
}

const output = originalEol === "\r\n" ? content.replace(/\n/g, "\r\n") : content;
fs.writeFileSync(targetPath, output, "utf8");

console.log(
  `${PREFIX} Correzione applicata: classifica ordinata per costo annuo e offerte con consulente non escluse per coincidenza del fornitore.`
);
