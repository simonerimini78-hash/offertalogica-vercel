# Fix temporaneo: migliori offerte per costo con consulente

Questo è un pacchetto incrementale per il branch `main` di `offertalogica-vercel`.

## Cosa modifica

Durante il deployment Vercel, lo script modifica esclusivamente `public/index.html` nella cartella di build e:

1. ordina la graduatoria economica per costo annuo crescente;
2. usa il risparmio solo come secondo criterio in caso di pari costo;
3. non elimina più un'offerta con consulente solo perché esiste un'offerta online dello stesso fornitore, tipo e fornitura;
4. continua a mostrare le prime tre offerte con consulente e le offerte partner online nel loro gruppo.

Non modifica variabili d'ambiente, secret, dati ARERA, API, lettore PDF, OTP o database.

## Caricamento su GitHub

1. Aprire il branch `main` del repository `offertalogica-vercel`.
2. Estrarre questo ZIP sul computer.
3. Caricare nella root di `main` i due elementi mantenendo i percorsi:
   - `package.json`
   - `scripts/apply-consultant-ranking-fix.mjs`
4. Confermare la sostituzione di `package.json`.
5. Usare come messaggio del commit:

   `Corregge ranking offerte con consulente per costo`

6. Attendere il deployment Production di Vercel.

## Controllo dopo il deployment

Ripetere lo stesso calcolo e verificare che il riquadro **Migliori offerte per costo con consulente** mostri le tre offerte non online con il costo annuo più basso.

Nel log di build Vercel deve comparire:

`[fix-offerte-consulente] Correzione applicata`

## Sicurezza

Lo script verifica che il codice precedente sia presente esattamente nel numero atteso. Se il file è cambiato, interrompe il deployment invece di applicare una modifica incerta.

Questa soluzione è intenzionalmente temporanea: applica la correzione nella build Vercel. In un aggiornamento successivo conviene incorporare direttamente le stesse modifiche in `public/index.html` e rimuovere il comando `postinstall`.
